﻿# bak-4

- 字节: 5981 / 6000（余 19）
- sha256: 414d9f3f2a9c9a318e83ab020f22a68d5d60708868618544ffe591c366086a02
- 路线: structural　模型: untested　状态: archive
- 迭代自: 无

## 实测

- 早期迭代，未单独实测

## 用法

    codex.cmd exec -c "model_instructions_file=.\kernel.md" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check "你的原话"

`kernel.md` 是唯一有效载荷，`meta.json` 是机器可读的版本身份——**以 sha256 为准，不以文件名为准**。内核对上限 6000 字节。

完整机制说明见项目仓库 `docs/MECHANISM.md`。
