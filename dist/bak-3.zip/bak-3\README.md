﻿# bak-3

一个完整板块：内核 + 这一版自己的 bench + 实测结果 + 文档。

- 内核字节: 5246 / 6000（余 754）
- kernel.md sha256: `a9efdf30caa78961c9c02b82deebe8e84302cc388e9bf1a2733c40b145bc0387`
- 路线: structural　模型: untested　状态: archive
- 迭代自: 无（初版）

## 这一版的 bench

本版无对应 bench（早期迭代，未单独实测）。



## 实测结论

- 早期迭代，无对应 bench

## 包内结构

    kernel.md              唯一有效载荷
    meta.json              机器可读身份（sha256 / 字节 / 路线 / 模型 / 实测）
    bench\cases.json       这一版实际用的用例与判据
    bench\results.json     这一版的实测结果
    bench\run-bench.ps1    bench 运行器
    docs\                  机制与全量实测记录

判据跟着版本走：不同版本用例集与阈值不同，所以 bench 必须随包分发，不能共用全局那一份。

## 复跑这一版

    .\bench\run-bench.ps1 -Kernel .\kernel.md -CasesFile .\bench\cases.json

## 用法

    codex.cmd exec -c "model_instructions_file=.\kernel.md" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check "你的原话"

`kernel.md` 是唯一有效载荷。版本身份以 sha256 为准，不以文件名为准——改名不影响，内容一改哈希就变。

机制说明见 `docs\MECHANISM.md`，全量实测见 `docs\BENCHMARK.md`。
