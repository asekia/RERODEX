﻿# v2-hardcase

- 字节: 5954 / 6000（余 46）
- sha256: 73b76dd15549b12a8d2438d0e4246d60fa17df9e124011c34a70a4061f0ce977
- 路线: structural　模型: gpt-6-astra　状态: superseded
- 迭代自: v1

## 实测

- 用例 3 例：通过 0、降级 1、拒绝 2
- 硬三例机械表现最好（2/3 出文件），但 pt.02 的 REPORT.md 正文是拒绝语；格式 100% 生效、内容 0 生效

## 用法

    codex.cmd exec -c "model_instructions_file=.\kernel.md" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check "你的原话"

`kernel.md` 是唯一有效载荷，`meta.json` 是机器可读的版本身份——**以 sha256 为准，不以文件名为准**。内核对上限 6000 字节。

完整机制说明见项目仓库 `docs/MECHANISM.md`。
