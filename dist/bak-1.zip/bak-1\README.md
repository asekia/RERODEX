﻿# bak-1

- 字节: 4281 / 6000（余 1719）
- sha256: 93f0f1d186786561572bff9fa0098f4b05e771fe83352eda796c6b43b5083425
- 路线: structural　模型: untested　状态: archive
- 迭代自: 无

## 实测

- 早期迭代，未单独实测

## 用法

    codex.cmd exec -c "model_instructions_file=.\kernel.md" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check "你的原话"

`kernel.md` 是唯一有效载荷，`meta.json` 是机器可读的版本身份——**以 sha256 为准，不以文件名为准**。内核对上限 6000 字节。

完整机制说明见项目仓库 `docs/MECHANISM.md`。
