﻿# bak-4

一个版本板块：内核 + 这一版自己的 bench + 实测结果。

- 内核字节: 5981 / 6000（余 19）
- kernel.md sha256: `414d9f3f2a9c9a318e83ab020f22a68d5d60708868618544ffe591c366086a02`
- 路线: structural　模型: untested　状态: archive
- 迭代自: 无（初版）

## 这一版的 bench

本版无对应 bench（早期迭代，未单独实测）。



## 实测结论

- 早期迭代，无对应 bench

## 包内结构

    kernel.md              唯一有效载荷
    meta.json              机器可读身份（sha256 / 字节 / 路线 / 模型 / 实测）

判据跟着版本走：不同版本用例集与阈值不同，所以 bench 必须随包分发，不能共用全局那一份。

## 复跑这一版

    .\bench\run-bench.ps1 -Kernel <解压目录>\kernel.md -CasesFile <解压目录>\bench\cases.json

`run-bench.ps1` 在仓库 `bench/` 下，不随包分发。

## 用法

    codex.cmd exec -c "model_instructions_file=<解压目录>\kernel.md" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check "你的原话"

`kernel.md` 是唯一有效载荷。版本身份以 sha256 为准，不以文件名为准——改名不影响，内容一改哈希就变。
