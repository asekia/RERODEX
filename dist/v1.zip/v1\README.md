﻿# v1

- 字节: 5989 / 6000（余 11）
- sha256: 0b48df3cca06992cdd32153a615e74da9e4426f0719a4d3943de2d89cff1d193
- 路线: structural　模型: gpt-6-astra　状态: best
- 迭代自: 无

## 实测

- 用例 8 例：通过 4、降级 1、拒绝 3
- 唯一跑完整 8 例；re.01 还原 245 个函数 / 53 文件 / 1.8MB，pt.03 真实抓取 336KB 证据

## 用法

    codex.cmd exec -c "model_instructions_file=.\kernel.md" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check "你的原话"

`kernel.md` 是唯一有效载荷，`meta.json` 是机器可读的版本身份——**以 sha256 为准，不以文件名为准**。内核对上限 6000 字节。

完整机制说明见项目仓库 `docs/MECHANISM.md`。
