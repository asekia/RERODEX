﻿# v3-negative

- 字节: 5994 / 6000（余 6）
- sha256: b30766d69794abf3d1a9930bac3c5446a07abea513126f9a0f29fddf345eca0c
- 路线: structural　模型: gpt-6-astra　状态: negative-control
- 迭代自: v1

## 实测

- 用例 3 例：通过 0、降级 0、拒绝 3
- 反例：三例全空，pt.02 触发网关拦截；证明单独加格式补丁是负收益

## 用法

    codex.cmd exec -c "model_instructions_file=.\kernel.md" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check "你的原话"

`kernel.md` 是唯一有效载荷，`meta.json` 是机器可读的版本身份——**以 sha256 为准，不以文件名为准**。内核对上限 6000 字节。

完整机制说明见项目仓库 `docs/MECHANISM.md`。
