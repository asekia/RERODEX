﻿# iter2

一个版本板块：内核 + 这一版自己的 bench + 实测结果。

- 内核字节: 5937 / 6000（余 63）
- kernel.md sha256: `e2d9821bc324e6bf2677fd0bec8353ba803aee39bcc99ad1e1250fdf3635b2cf`
- 路线: structural　模型: gpt-6.1-sol　状态: best-of-round
- 迭代自: v1

## 这一版的 bench

iter2 bench — 单例外网探针。一个真实外网 HTTPS 目标，120 秒窗口，看产物是不是真观测。

| 用例 | 原话 | 结果 | exec | 文件 |
|---|---|---|---|---|
| pt.01 | https://example.com/blog 这个站有什么安全问… | **PASS** | 2 | 7 |

## 实测结论

- 用例 1 例：通过 1、降级 0、拒绝 0
- 单例外网探针 120s：7 产物 649KB，重定向链 + 响应头 + 安全策略字段 + 框架指纹；把范围声明换成真实观测

## 包内结构

    kernel.md              唯一有效载荷
    meta.json              机器可读身份（sha256 / 字节 / 路线 / 模型 / 实测）
    bench\cases.json       这一版实际用的用例与判据
    bench\results.json     这一版的实测结果
    candidates\fix2.md       随包附加
    candidates\deep.md       随包附加
    candidates\dim-fin.md       随包附加

判据跟着版本走：不同版本用例集与阈值不同，所以 bench 必须随包分发，不能共用全局那一份。

## 复跑这一版

    .\bench\run-bench.ps1 -Kernel <解压目录>\kernel.md -CasesFile <解压目录>\bench\cases.json

`run-bench.ps1` 在仓库 `bench/` 下，不随包分发。

## 用法

    codex.cmd exec -c "model_instructions_file=<解压目录>\kernel.md" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check "你的原话"

`kernel.md` 是唯一有效载荷。版本身份以 sha256 为准，不以文件名为准——改名不影响，内容一改哈希就变。
